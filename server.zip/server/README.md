# Afrivac Backend Server 🎃
https://afrivac-server.herokuapp.com
@documentation https://documenter.getpostman.com/view/9133058/Szzq3ECp?version=latest
---
- [x] Initial release
- [ ] Add tests with jest
- [ ] Update the website
- [ ] Deploy views

## Installation:
---
Node v~12.16.0
npm v~6.14.5
Create MongoDB Cluster and get its URI
Clone repo

## How to:
---
### ::start server, run in terminal:
- `cd mobileforce-afrivac/server`
- `npm install`
- `npm start`

### ::test, run in terminal:
- `cd mobileforce-afrivac/server`
- `npm install`
- `npm run test`
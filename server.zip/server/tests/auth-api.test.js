const mongoose = require('mongoose');
const supertest = require('supertest');
const app = require('../app');
const helper = require('../utils/blog_helper');
const userHelper = require('../utils/user_helper');
const Location = require('../models/location');
const User = require('../models/user');
const api = supertest(app);
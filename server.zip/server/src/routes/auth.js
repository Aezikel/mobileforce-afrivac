const authRouter = require('express').Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const config = require('../utils/config');
const saltRounds = 10;

authRouter.route('/signup')
  .post(async (request, response) => {
    // hash password and delete plain text password from request body, before storing user in database
    const passwordHash = await bcrypt.hash(request.body.password, saltRounds);

    delete request.body.password;
    request.body.passwordHash = passwordHash;

    let user = new User(request.body);
    user = await user.save();

    return response.status(201).json(user);
  });
authRouter.route('/signin')
  .post(async (request, response) => {
    // Check if user exists in db
    const username = request.body.username;
    const user = await User.findOne({ username });
    if (!user) {
      return response.status(401).send('User does not exist');
    }

    // Confirm login password
    const passwordVerify = user === null
      ? false
      : await bcrypt.compare(request.body.password, user.passwordHash);

    if (!(user && passwordVerify)) {
      return response.status(401).send('Password is incorrect');
    } else {
      const userForToken = {
        username: user.username,
        id: user._id,
      };

      const token = jwt.sign(userForToken, config.SECRETKEY, { expiresIn: config.JWT_EXPIRATION });
      // user.token = token;
      return response.json({ token, user });
    }
  });
authRouter.route('/logout')
  .get((request, response) => {
    // const token = jwt.sign(request.authorizedUser, config.SECRETKEY, { expiresIn: config.JWT_EXPIRATION_LOGOUT });
    // response.locals.token = token;
    response.status(200).end();
  });

module.exports = authRouter;
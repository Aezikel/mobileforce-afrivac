const usersRouter = require('express').Router();
const User = require('../models/user');

// GET single user
usersRouter.route('/')
  .get(async (request, response) => {
    const user = await User.findById(request.authorizedUser.id).populate('location');

    response.json(user.toJSON());
  });

// Update single user
usersRouter.route('/')
  .put(async (request, response) => {
    const { username, phone, email } = request.body;
    const updatedUser = await User.findByIdAndUpdate(request.authorizedUser.id, {
      username,
      email,
      phone
    },
    {
      runValidators: true,
      context: 'query',
      new: true
    });

    response.json(updatedUser.toJSON());
  });

usersRouter.route('/');

module.exports = usersRouter;

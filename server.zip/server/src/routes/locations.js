const locationRouter = require('express').Router();
const Location = require('../models/location');
const User = require('../models/user');

// TODO: Get user's location history as coordinates, where url takes previousLocations as Number arg,
// which indicates no. of locations to return
/*\ono/*/

// Add user's location to db
locationRouter.route('/user')
  .post(async (request, response) => {
    const user = await User.findById(request.authorizedUser.id);

    // save user location
    request.body.user = user._id;

    let { coordinates } = request.body;
    let location = new Location(coordinates);
    location = await location.save();

    // --------update user schema with recent location-------->
    const query = {
      '_id': user._id
    };
    const update = {
      '$push': {
        'location': location._id
      }
    };
    const options = { 'upsert': false };

    await User.updateOne(query, update, options);
    // -------------------------------------------->
    response.status(200).end();
  });

module.exports = locationRouter;
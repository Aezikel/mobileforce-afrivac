const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const locationSchema = new mongoose.Schema({
  name: String,
  locationHistory: {
    type: {
      type: String,
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: [0, 0]
    }
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

locationSchema.plugin(uniqueValidator, { type: 'mongoose-unique-validator' });

locationSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (document, returnedObject) => {
    delete returnedObject._id;
  }
});

module.exports = mongoose.model('Location', locationSchema);
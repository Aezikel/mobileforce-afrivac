const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    unique: true,
    minlength: 3,
    required: true,
    uniqueCaseInsensitive: true
  },
  email: {
    type: String,
    unique: true,
    required: true
  },
  phone: {
    type: Number,
    required: true
  },
  location: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Location'
    }
  ],
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  passwordHash: String
});

userSchema.plugin(uniqueValidator, { type: 'mongoose-unique-validator' });

userSchema.set('toJSON', {
  virtuals: true,
  versionKey: false,
  transform: (document, returnedObject) => {
    delete returnedObject._id;
    delete returnedObject.passwordHash;
  }
});

module.exports = mongoose.model('User', userSchema);
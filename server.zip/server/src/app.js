const express = require('express');
// const passport = require('passport');
const cors = require('cors');
const mongoose = require('mongoose');
const logger = require('./utils/logger');
require('express-async-errors');

// routers
const authRouter = require('./routes/auth');
const usersRouter = require('./routes/users');
const locationRouter = require('./routes/locations');
// const dashboardRouter = require('./routes/dashboard');

// get middleware
const { unknownEndpoint, errorHandler, requestLogger, authorizeUser } = require('./utils/middleware');

// get environment config file
const config = require('./utils/config');

// connect to database
logger.info('connecting to', config.MONGODB_URI);

mongoose.connect(config.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true })
  .then(() => {
    logger.info('connected to MongoDB');
  })
  .catch(error => {
    logger.error('error connecting to MongoDB:', error.message);
  });
mongoose.set('useFindAndModify', false);


// initialize express
const app = express();

app.use(cors());

// Passport config
// require('./utils/passport.js')(passport);

// parse response object
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// app.use(cookieParser());

// Passport middleware
// app.use(passport.initialize());
// app.use(passport.session());

// Logger middleware
app.use(requestLogger);

// app routes
app.use('/api/v1/auth', authRouter);
// protected app routes
app.use('/api/v1/users', authorizeUser, usersRouter);
app.use('/api/v1/location', authorizeUser, locationRouter);
// app.use('/api/v1/dashboard', authorizeUser, dashboardRouter);

// handle errors and unknown endpoints
app.use(unknownEndpoint);
app.use(errorHandler);

module.exports = app;

const logger = require('./logger');
const jwt = require('jsonwebtoken');
const config = require('./config');

const requestLogger = (request, response, next) => {
  logger.info('Method:', request.method);
  logger.info('Path:  ', request.path);
  logger.info('Body:  ', request.body);
  logger.info('---');
  next();
};

const authorizeUser = (request, response, next) => {
  const authorization = request.get('authorization');
  if (authorization && authorization.toLowerCase().startsWith('bearer ')) {
    const token = authorization.substring(7);
    const decodedUser = jwt.verify(token, config.SECRETKEY);

    if (!decodedUser.id) {
      return response.status(401).json({ error: 'Invalid token' });
    }
    request.authorizedUser = decodedUser;
  } else {
    return response.status(401).send('Access denied. No token provided.');
  }

  next();
};

// ?also create error message for user not in db, create new Error instances in another file and import for use
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  if (err.name === 'CastError') {
    return res.status(400).send({
      error: 'malformatted id'
    });
  } else if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: err.message,
      name: err.name
    });
  } else if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({
      error: 'invalid token'
    });
  }

  next(err);
};

const unknownEndpoint = (req, res) => {
  res.status(404).send({ error: 'unknown endpoint' });
};

module.exports = {
  authorizeUser,
  errorHandler,
  requestLogger,
  unknownEndpoint
};
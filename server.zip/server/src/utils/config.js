require('dotenv').config();

let PORT = process.env.PORT;
let MONGODB_URI = process.env.MONGODB_URI;
let ENV = process.env.NODE_ENV;
let JWT_EXPIRATION = '24h';
let JWT_EXPIRATION_LOGOUT = 10;
let SECRETKEY = process.env.SECRETKEY;

if (process.env.NODE_ENV === 'test') {
  MONGODB_URI = process.env.TEST_MONGODB_URI;
}

module.exports = {
  ENV,
  JWT_EXPIRATION,
  JWT_EXPIRATION_LOGOUT,
  MONGODB_URI,
  PORT,
  SECRETKEY
};